import './style.css'

const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
let user=null, reqs=[], stack=[], cur="splash";
const store={get(k){try{return JSON.parse(localStorage.getItem(k))}catch(e){return null}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
user=store.get("brr_user"); reqs=store.get("brr_reqs")||[];
const th=store.get("brr_theme"); if(th) setTheme(th);

function setTheme(t){document.documentElement.dataset.theme=t;$("#pTheme").textContent=t==="dark"?"Escuro":"Claro";store.set("brr_theme",t)}
function toast(m){const t=$("#toast");t.textContent=m;t.classList.add("on");clearTimeout(toast.i);toast.i=setTimeout(()=>t.classList.remove("on"),2400)}
function go(s,push=true){
  if(s==="back"){s=stack.pop()||"home";push=false}
  else if(push&&cur!==s&&cur!=="splash")stack.push(cur);
  cur=s;$$(".screen").forEach(e=>e.classList.toggle("on",e.dataset.s===s));
  if(s==="historico")renderHist(); if(s==="perfil")renderProfile();
  scrollTo(0,0);
}
function renderHist(){
  const h=$("#hist");
  h.innerHTML=reqs.length?reqs.map(r=>`<div class="it"><b></b><small></small></div>`).join(""):"Nenhuma solicitação feita no momento...";
  if(reqs.length)$$(".it",h).forEach((el,i)=>{const r=reqs[reqs.length-1-i];$("b",el).textContent=r.assunto;$("small",el).textContent=r.data+" · "+r.cidade+"/"+r.uf})
}
function renderProfile(){$("#pUser").textContent=user?user.nome:"Usuário";$("#pMail").textContent="E-mail: "+(user?user.email:"—")}

const masks={tel:v=>{v=v.replace(/\D/g,"").slice(0,11);return v.length>10?v.replace(/(\d\d)(\d{5})(\d{4})/,"($1) $2-$3"):v.length>6?v.replace(/(\d\d)(\d{4})(\d{0,4})/,"($1) $2-$3"):v.length>2?v.replace(/(\d\d)(\d*)/,"($1) $2"):v},
 cnpj:v=>{v=v.replace(/\D/g,"").slice(0,14);return v.replace(/(\d{2})(\d)/,"$1.$2").replace(/(\d{2})\.(\d{3})(\d)/,"$1.$2.$3").replace(/\.(\d{3})(\d)/,".$1/$2").replace(/(\d{4})(\d)/,"$1-$2")}};
document.addEventListener("input",e=>{const m=e.target.dataset&&e.target.dataset.mask;if(m)e.target.value=masks[m](e.target.value)});

function cnpjOk(c){c=c.replace(/\D/g,"");if(c.length!==14||/^(\d)\1+$/.test(c))return false;
 const d=(n)=>{let s=0,p=n-7;for(let i=0;i<n;i++){s+=c[i]*p--;if(p<2)p=9}const r=s%11;return r<2?0:11-r};
 return d(12)==c[12]&&d(13)==c[13]}
function validate(form){
  let ok=true;
  $$("input,select",form).forEach(i=>{
    const v=i.value.trim();let m="";
    if(!v)m="Preencha este campo.";
    else if(i.name==="email"&&!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v))m="Informe um e-mail válido.";
    else if(i.name==="tel"&&v.replace(/\D/g,"").length<10)m="Informe o telefone com DDD.";
    else if(i.name==="cnpj"&&!cnpjOk(v))m="CNPJ inválido. Confira os 14 dígitos.";
    i.parentElement.querySelector(".err").textContent=m;i.setAttribute("aria-invalid",!!m);
    if(m&&ok){ok=false;i.focus()}
  });
  return ok;
}

$$("[data-go]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.go)));
$$("[data-quote]").forEach(b=>b.addEventListener("click",()=>{
  $("#a").value=b.dataset.quote;
  if(user){$("#rn").value=user.nome;$("#re").value=user.email;$("#rt").value=user.tel;$("#rc").value=user.empresa;$("#rj").value=user.cnpj}
  go("orcamento");
}));
["AC","AL","AP","AM","BA","CE","DF","ES","GO","MA","MT","MS","MG","PA","PB","PR","PE","PI","RJ","RN","RS","RO","RR","SC","SP","SE","TO"].forEach(u=>$("#uf").add(new Option(u,u)));

$("#fLogin").addEventListener("submit",e=>{e.preventDefault();
  if(!validate(e.target))return;
  user=Object.fromEntries(new FormData(e.target));store.set("brr_user",user);
  stack=[];go("home",false);toast("Bem-vindo, "+user.nome.split(" ")[0]+"!");
});
$("#fReq").addEventListener("submit",e=>{e.preventDefault();
  if(!validate(e.target))return;
  const r=Object.fromEntries(new FormData(e.target));r.data=new Date().toLocaleDateString("pt-BR");
  reqs.push(r);store.set("brr_reqs",reqs);e.target.reset();
  stack=["home"];go("historico",false);toast("Solicitação enviada!");
});
$("#bTheme").addEventListener("click",()=>setTheme(document.documentElement.dataset.theme==="dark"?"light":"dark"));
$("#bLang").addEventListener("click",()=>toast("Outros idiomas em breve."));
$("#bOut").addEventListener("click",()=>{if(!confirm("Deseja sair da conta?"))return;
  user=null;try{localStorage.removeItem("brr_user")}catch(e){}stack=[];go("login",false)});

go(user?"home":"splash",false);
