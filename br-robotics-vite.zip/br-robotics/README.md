# BR Robotics

App mobile-first feito com Vite (JavaScript puro).

    npm install
    npm run dev       # desenvolvimento
    npm run build     # gera a pasta dist/
    npm run preview   # testa o build

Estrutura: `index.html` (telas), `src/main.js` (navegação, validação, histórico, tema), `src/style.css`, `public/img/` (logo, robô, fundo).
